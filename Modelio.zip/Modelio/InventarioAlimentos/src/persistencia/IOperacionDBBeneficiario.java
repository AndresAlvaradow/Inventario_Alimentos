package persistencia;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("18bc01d8-9d17-4afb-af36-ac4a73d487ac")
public interface IOperacionDBBeneficiario {
    @objid ("3aa06f3f-042a-42bd-a840-0877b160aa10")
    void insertar();

    @objid ("2ae16bda-cf7e-4701-8707-89fdef62e8b5")
    void getAll();

    @objid ("72881bb4-1612-4d1a-be2a-c16c927d07fb")
    void validarExistencia();

}
