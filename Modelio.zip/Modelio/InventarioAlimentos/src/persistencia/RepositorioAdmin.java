package persistencia;

import com.modeliosoft.modelio.javadesigner.annotations.objid;
import domain.entities.Administrador;

@objid ("fd74fb50-cf31-434d-bb95-87267f525e08")
public class RepositorioAdmin implements IOperacionDBAdmin {
    @objid ("bc6a54ab-86ca-41a5-890c-14e0fa0b3160")
    public Administrador administrador;

    @objid ("e690fc44-c02a-4ae9-9bed-ab074279ccff")
    public void insertarAdmin() {
    }

    @objid ("45d65f1e-fb29-431a-8400-7e67c0dc4ad7")
    public void getAllAdmin() {
    }

}
