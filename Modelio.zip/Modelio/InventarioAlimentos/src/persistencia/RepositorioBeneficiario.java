package persistencia;

import com.modeliosoft.modelio.javadesigner.annotations.objid;
import domain.entities.Beneficiario;

@objid ("199dbfe7-a6c9-4ff5-a3fd-764be91a09aa")
public class RepositorioBeneficiario implements IOperacionDBBeneficiario {
    @objid ("3dc2a44b-c6f3-4af5-bf73-9e4bdead7326")
    public Beneficiario beneficiarios;

    @objid ("9471e7bb-10a5-455d-be4e-53789c1e7192")
    public void insertar() {
    }

    @objid ("3edd006f-87e0-47d3-b7fc-a3a2eb1d2fd4")
    public void getAll() {
    }

    @objid ("fe29c1cc-9e9f-4615-9082-73a610e95811")
    public void validarExistencia() {
    }

}
