package persistencia;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("f7622431-b447-474c-ab91-5eb17e5923e5")
public interface IOperacionDBEntrega {
    @objid ("78a68515-cc20-4023-96ea-f47ef02670b0")
    void insertarEntrega();

    @objid ("8bc7e15d-0a32-457b-a200-b46d9fdcc92d")
    void getAllEntregas();

    @objid ("a56846c0-c0d1-4710-ac51-bc8d71361f8d")
    void validarExistencia();

}
