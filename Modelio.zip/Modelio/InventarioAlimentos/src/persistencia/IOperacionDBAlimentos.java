package persistencia;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("b6b9054f-f668-4ade-a1ab-56c0baf7491c")
public interface IOperacionDBAlimentos {
    @objid ("fe5a5558-055f-40df-a988-ca1e3100d12c")
    void insertarAlimentos();

    @objid ("552c9eb5-e88c-485b-9e7a-b3eff18e6465")
    void getAllAlimentos();

    @objid ("c70484c1-b069-4bd3-956b-27f7d8f33d55")
    void validarExistencia();

}
