package persistencia;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("1ea4d5fc-d711-4ca4-bfa5-f4742ee02bd1")
public interface IOperacionDBAdmin {
    @objid ("f2c50a17-752f-495d-9cc6-da1f80d0401e")
    void insertarAdmin();

    @objid ("6a75b117-9ce5-4678-bd7c-2cae3be9b72f")
    void getAllAdmin();

}
