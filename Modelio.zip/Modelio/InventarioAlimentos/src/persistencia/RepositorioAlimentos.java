package persistencia;

import com.modeliosoft.modelio.javadesigner.annotations.objid;
import domain.entities.Alimento;

@objid ("9a3b10fa-a784-4d28-b067-dc44fd1d3a29")
public class RepositorioAlimentos implements IOperacionDBAlimentos {
    @objid ("f4c28705-a347-4da1-82ce-9ae9ecbbc062")
    public Alimento alimentos;

    @objid ("1c7a7fff-c656-4923-9908-e69714229c00")
    public void insertarAlimentos() {
    }

    @objid ("c03fb9bf-ac41-4beb-8516-8b953c7aa988")
    public void getAllAlimentos() {
    }

    @objid ("f998f758-256d-459c-8b39-e8c135bd7058")
    public void validarExistencia() {
    }

}
