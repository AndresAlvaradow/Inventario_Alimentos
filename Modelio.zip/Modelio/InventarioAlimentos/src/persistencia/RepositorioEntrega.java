package persistencia;

import com.modeliosoft.modelio.javadesigner.annotations.objid;
import domain.entities.Entrega;

@objid ("0fed17ee-957b-456f-bed1-44c3e7ea7a05")
public class RepositorioEntrega implements IOperacionDBEntrega {
    @objid ("3ca8d6af-5814-47eb-aa78-c24626a17197")
    public Entrega entrega;

    @objid ("677d2486-8a31-4369-8189-ab97a2923cec")
    public void insertarEntrega() {
    }

    @objid ("fd114e84-f3f2-49fa-9e01-db198fdc7c3c")
    public void getAllEntregas() {
    }

    @objid ("291accd1-fcc5-4ce6-a9ef-dcfe30a1ab7d")
    public void validarExistencia() {
    }

}
