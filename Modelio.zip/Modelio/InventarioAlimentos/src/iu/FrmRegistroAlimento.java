package iu;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("3b8f66ae-600b-44bb-8c66-9ed74226eb0b")
public class FrmRegistroAlimento {
    @objid ("735b4daa-c5b2-4ea5-95ad-fd941a98fdfd")
    public void jButton1Action() {
    }

}
