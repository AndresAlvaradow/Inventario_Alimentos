package iu;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("fe3e8110-e7c9-4168-9208-5d67479456cd")
public class FrmBuscarBeneficiario {
    @objid ("9c80e5c5-0fee-45ba-9066-e84e79f0bfe3")
    public void jButton1Action() {
    }

}
