package iu;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("c5a3de40-3677-479a-8c76-45fc807928b7")
public class FrmRegistroBeneficiario {
    @objid ("6b06083f-a15b-4ed8-a51c-f57ad587a962")
    public void jButton1Action() {
    }

}
