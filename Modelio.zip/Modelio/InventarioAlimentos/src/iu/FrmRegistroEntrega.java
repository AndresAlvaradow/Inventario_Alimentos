package iu;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("11eff519-3e19-44a6-8d25-3240f755cccd")
public class FrmRegistroEntrega {
    @objid ("d839e4de-d8cb-4f96-a396-35ed6c6fa300")
    public void jButton1Action() {
    }

}
