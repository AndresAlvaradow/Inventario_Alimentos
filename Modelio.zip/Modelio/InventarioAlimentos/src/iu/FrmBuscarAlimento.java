package iu;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("e8792033-4ec7-4203-9d82-3ad39c26678d")
public class FrmBuscarAlimento {
    @objid ("0c1d89b2-8f0f-4d4d-9cea-27f4b302cd08")
    public void jButton1Action() {
    }

}
