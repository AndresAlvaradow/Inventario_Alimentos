package adaptadores;

import com.modeliosoft.modelio.javadesigner.annotations.objid;
import domain.RegistroBeneficiario;
import persistencia.RepositorioBeneficiario;

@objid ("17f1048b-fa2a-4789-bec8-f3b086a3ff38")
public class RegistrarBeneficiarioPortInt {
    @objid ("8fa7b925-03ad-4aad-aacd-1dfc84413f01")
    public RepositorioBeneficiario repositorioBeneficiario;

    @objid ("d30764ad-9b1a-4f97-96db-7a991b49e34c")
    public RegistrarBeneficiarioPortInt(RegistroBeneficiario RegistroB, String repositorioB) {
    }

}
