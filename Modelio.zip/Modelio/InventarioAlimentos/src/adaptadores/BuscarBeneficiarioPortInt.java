package adaptadores;

import com.modeliosoft.modelio.javadesigner.annotations.objid;
import persistencia.RepositorioBeneficiario;

@objid ("ded3a86c-b14b-4849-a499-3a4ab279e069")
public class BuscarBeneficiarioPortInt {
    @objid ("c2232a33-f464-43ab-96c8-7a1e95abcb09")
    public RepositorioBeneficiario repositorioBeneficiario;

    @objid ("ce459c59-a1f2-4404-a7b4-b6d7d3087885")
    public BuscarBeneficiarioPortInt() {
    }

}
