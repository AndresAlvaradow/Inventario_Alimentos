package adaptadores;

import com.modeliosoft.modelio.javadesigner.annotations.objid;
import domain.RegistroEntregaX;
import persistencia.RepositorioEntrega;

@objid ("61c49bfa-0078-4230-80bf-0c78069ed040")
public class RegistrarEntregaPortInt {
    @objid ("3cff4df6-142c-4ad4-9281-74e6bc1aaa40")
    public RepositorioEntrega repositorioEntrega;

    @objid ("ab0f98bd-04a1-40f4-a672-ab1db1b120f4")
    public RegistrarEntregaPortInt(RegistroEntregaX RegistroEntrega, String repositorioE) {
    }

}
