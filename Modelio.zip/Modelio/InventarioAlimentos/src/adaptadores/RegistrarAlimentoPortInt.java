package adaptadores;

import com.modeliosoft.modelio.javadesigner.annotations.objid;
import domain.RegistroAlimentos;
import persistencia.RepositorioAlimentos;

@objid ("e2709e1f-af92-41bf-b3d3-b820f0a11567")
public class RegistrarAlimentoPortInt {
    @objid ("260b6824-9de4-41e3-8333-16a9ec1407c1")
    public RepositorioAlimentos repositorioAlimentos;

    @objid ("b44a8e59-d9a3-47fa-bf99-2254d7d9ea29")
    public RegistrarAlimentoPortInt(RegistroAlimentos RegistroAl, String repositorioA) {
    }

}
