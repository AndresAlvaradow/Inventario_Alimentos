package adaptadores;

import com.modeliosoft.modelio.javadesigner.annotations.objid;
import persistencia.RepositorioAlimentos;

@objid ("ac59a18b-cea2-484e-8156-79db30cd9a8f")
public class BuscarAlimentoPortInt {
    @objid ("b11251ae-bb80-4632-ad04-a5d79f847010")
    public RepositorioAlimentos repositorioAlimentos;

    @objid ("014d0031-674f-42cb-aef9-b86ab329e88c")
    public BuscarAlimentoPortInt() {
    }

}
