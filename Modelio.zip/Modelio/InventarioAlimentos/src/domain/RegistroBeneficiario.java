package domain;

import com.modeliosoft.modelio.javadesigner.annotations.objid;
import domain.entities.Beneficiario;
import persistencia.RepositorioBeneficiario;

@objid ("6d321179-c629-47a0-b6d9-9c6fcb4f4010")
public interface RegistroBeneficiario {
    @objid ("c680e7e4-2433-4970-9031-bbe802e0fe58")
    void registrarBeneficiar(Beneficiario Beneficiario, RepositorioBeneficiario RepositorioB);

    @objid ("2470f701-3e4f-4d78-8f3b-074f8ad0431b")
    boolean validarExistenciaB(Beneficiario Beneficiario, String cedula);

}
