package domain.usecase;

import com.modeliosoft.modelio.javadesigner.annotations.objid;
import domain.RegistroAlimentos;
import domain.entities.Alimento;
import persistencia.RepositorioAlimentos;

@objid ("732488bf-bafa-4207-bc81-b5602b03a2d9")
public class RegistrarAlimentos implements RegistroAlimentos {
    @objid ("76e9542a-9085-4d72-a017-3481c1cbc307")
    public void registrarAlimentos(Alimento Alimento, RepositorioAlimentos RepoAlimento) {
    }

    @objid ("f186cc8f-0fe9-442b-9a88-207e97cf1509")
    public boolean validarExistenciaA(Alimento Alimento, String nombreAlimento) {
    }

}
