package domain.usecase;

import com.modeliosoft.modelio.javadesigner.annotations.objid;
import domain.RegistroEntregaX;
import domain.entities.Entrega;
import persistencia.RepositorioEntrega;

@objid ("1d266061-1f07-426b-ae05-78b44b78723c")
public class RegistrarEntregaAlimentos implements RegistroEntregaX {
    @objid ("6d140872-1851-4b81-90c3-39797f634659")
    public void registrarEntrega(Entrega Entrega, RepositorioEntrega RepoEntrega) {
    }

    @objid ("1da8fab7-149f-4c92-a703-dbf6f0f38235")
    public boolean ValidarExistenciaE(Entrega Entrega, String cedula, String nombreA) {
    }

}
