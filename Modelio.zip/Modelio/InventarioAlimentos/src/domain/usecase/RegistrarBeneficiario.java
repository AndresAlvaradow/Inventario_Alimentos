package domain.usecase;

import com.modeliosoft.modelio.javadesigner.annotations.objid;
import domain.RegistroBeneficiario;
import domain.entities.Beneficiario;
import persistencia.RepositorioBeneficiario;

@objid ("ed203369-c1f5-42a2-b1b8-30b0424eccef")
public class RegistrarBeneficiario implements RegistroBeneficiario {
    @objid ("3ce922ed-c990-4e39-be2e-1024100ae51f")
    public void registrarBeneficiar(Beneficiario Beneficiario, RepositorioBeneficiario RepositorioB) {
    }

    @objid ("d382aaa0-d1cf-46f0-a0b3-3e42a4a6b08f")
    public boolean validarExistenciaB(Beneficiario Beneficiario, String cedula) {
    }

}
