package domain.usecase;

import com.modeliosoft.modelio.javadesigner.annotations.objid;
import domain.BuscarA;
import domain.entities.Alimento;

@objid ("05fcccf8-23d7-4924-8edb-3f37d1c85f63")
public class BuscarAlimentos implements BuscarA {
    @objid ("936a8fa1-30f9-47be-9977-7d7353e22804")
    public Alimento buscar(String nombreAl) {
    }

}
