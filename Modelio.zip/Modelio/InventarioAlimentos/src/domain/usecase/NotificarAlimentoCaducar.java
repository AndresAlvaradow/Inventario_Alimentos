package domain.usecase;

import com.modeliosoft.modelio.javadesigner.annotations.objid;
import domain.Notificacion;

@objid ("661df099-ba18-4cf6-9896-91505e3ee9f3")
public class NotificarAlimentoCaducar implements Notificacion {
    @objid ("8dbac7db-9ef4-4d99-a7a9-d105980aebc0")
    public String enviarNotificacion(String Alimento, String fechaCaducidad) {
    }

}
