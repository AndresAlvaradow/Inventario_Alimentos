package domain.usecase;

import com.modeliosoft.modelio.javadesigner.annotations.objid;
import domain.BuscarB;
import domain.entities.Beneficiario;

@objid ("c9f6dd03-efdd-4f6a-b0c4-a03a5af4771b")
public class BuscarBeneficiario implements BuscarB {
    @objid ("9f438981-0b1d-421d-9f1d-9c4323e5e26c")
    public Beneficiario buscarBe(String cedula) {
    }

}
