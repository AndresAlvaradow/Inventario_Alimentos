package domain;

import com.modeliosoft.modelio.javadesigner.annotations.objid;
import domain.entities.Beneficiario;

@objid ("275ae596-3db5-4191-a6fd-a2c9432bd382")
public interface BuscarB {
    @objid ("6f5aa60d-a2de-4c46-964e-a0387ec45d50")
    Beneficiario buscarBe(String cedula);

}
