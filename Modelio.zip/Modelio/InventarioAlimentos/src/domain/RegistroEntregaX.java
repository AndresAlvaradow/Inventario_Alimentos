package domain;

import com.modeliosoft.modelio.javadesigner.annotations.objid;
import domain.entities.Entrega;
import persistencia.RepositorioEntrega;

@objid ("87454074-5e62-458e-aabd-86e78703a34b")
public interface RegistroEntregaX {
    @objid ("9f9ac6fe-29c6-44ce-a627-d984012d2c2e")
    void registrarEntrega(Entrega Entrega, RepositorioEntrega RepoEntrega);

    @objid ("91f07fa9-5b4f-45dc-b40b-171c2ecdbe88")
    boolean ValidarExistenciaE(Entrega Entrega, String cedula, String nombreA);

}
