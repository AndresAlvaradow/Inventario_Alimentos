package domain;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("0e115118-c7ae-4c50-a25b-6494a7125755")
public interface Registrar {
    @objid ("09ebbefa-63ea-4b52-8065-840ce109c95f")
    void registrar();

    @objid ("3c7de896-62f2-48d4-be0b-c5bf6c841aca")
    void existeBeneficiario();

}
