package domain;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("0a91dc33-6765-4cce-9c8d-477c3b20564d")
public interface Buscar {
    @objid ("0a796c95-2818-45c1-ac88-e023692f5c55")
    void busqueda();

}
