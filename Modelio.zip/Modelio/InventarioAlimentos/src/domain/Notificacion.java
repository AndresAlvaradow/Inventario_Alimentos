package domain;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("a46d8a2d-5c91-43df-bafe-364cb461ed21")
public interface Notificacion {
    @objid ("18ed8707-a2b2-454f-893c-8c968061ac78")
    String enviarNotificacion(String Alimento, String fechaCaducidad);

}
