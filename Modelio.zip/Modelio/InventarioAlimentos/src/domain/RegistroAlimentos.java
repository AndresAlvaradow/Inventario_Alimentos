package domain;

import com.modeliosoft.modelio.javadesigner.annotations.objid;
import domain.entities.Alimento;
import persistencia.RepositorioAlimentos;

@objid ("9152b257-7780-4012-b663-0224770bf9c0")
public interface RegistroAlimentos {
    @objid ("8d2f2eb9-e5bd-4448-947b-7b46cac691c9")
    void registrarAlimentos(Alimento Alimento, RepositorioAlimentos RepoAlimento);

    @objid ("c09a0b0c-2b18-4dbf-8bd8-7dfeff8fc1b8")
    boolean validarExistenciaA(Alimento Alimento, String nombre);

}
