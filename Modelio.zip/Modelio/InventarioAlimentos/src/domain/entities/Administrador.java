package domain.entities;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("d1e0fbd3-b02a-4d52-b545-c3fd95642eae")
public class Administrador {
    @objid ("fa26710a-682b-454b-b4c0-843c2b0c2b2a")
    public String nombres;

    @objid ("a750d432-bd0b-42ee-803c-2a599d2248f7")
    public String apellidos;

    @objid ("c4f15500-df05-4e69-ba2c-b83838e75324")
    public String email;

    @objid ("5974f8de-64c2-40c6-bb15-f4dec0bd059c")
    public String telefono;

    @objid ("4aeca65d-2d35-4a92-b511-72d6112a9e61")
    public void registrarAlimento() {
    }

    @objid ("871c4720-65e7-4082-8fd0-544a1552f688")
    public void registrarBeneficiario() {
    }

    @objid ("10ba1cac-02fc-4eae-b60d-40cab3e62208")
    public void buscarAlimento() {
    }

    @objid ("f19be84e-6648-4f23-af27-70b561f0875a")
    public void buscarBeneficiario() {
    }

    @objid ("7a3794f9-d5d4-4d58-b886-28535363d89a")
    public Administrador() {
    }

}
