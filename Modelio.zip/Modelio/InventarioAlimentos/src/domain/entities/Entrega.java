package domain.entities;

import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("4098048d-5666-4a42-b7b1-1b15788269a3")
public class Entrega {
    @objid ("ce7a3a8e-f676-4058-91b3-38ace0979d1e")
    public String Fecha;

    @objid ("47124303-2f50-4df1-8e44-9090301a35a3")
    public List<Alimento> alimento = new ArrayList<Alimento> ();

    @objid ("da5c9be6-59d9-480e-8f30-614f6367c77c")
    public Beneficiario beneficiario;

    @objid ("392b7b7f-d6f9-46a7-9f0a-3d2b0dc018b5")
    public Entrega() {
    }

}
