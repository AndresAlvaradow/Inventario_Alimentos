package domain.entities;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("0414f39e-1f84-495a-a433-a2371c1ad26e")
public class Beneficiario {
    @objid ("228a65f8-338d-4e9c-8f15-37ab614f69f4")
    public String nombres;

    @objid ("82e104c7-4721-4b89-ab47-6245a29745ab")
    public String apellidos;

    @objid ("9398295f-8524-4fa1-8ff1-ca94915546a8")
    public String cedula;

    @objid ("08dde95e-b4e2-4c95-a163-431542aa8b05")
    public Beneficiario() {
    }

}
