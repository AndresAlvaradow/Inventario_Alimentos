package domain.entities;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("759723e2-fb8a-4d91-aed7-970467d44830")
public class Alimento {
    @objid ("14066adc-6e9d-4842-9f86-4662af0fe7c1")
    public String nombreAlimento;

    @objid ("b11eb63f-cdf2-4365-a0aa-a0a5fb2ca112")
    public String categoria;

    @objid ("239beedf-495c-4d09-8472-c9c4dc1a5888")
    public String tipo;

    @objid ("cb2145ea-f7ee-4448-b162-b93762f9d5da")
    public String fechaRecepcion;

    @objid ("0a5eb3f3-3740-4362-909d-84445ce51175")
    public String fechaCaducidad;

    @objid ("bf1314d6-7267-4395-ad07-372749a75f71")
    public int cantidad;

    @objid ("cd3f7a7b-0b3c-42dd-8346-67076db7b34a")
    public void notificacionAlimentoCaducar() {
    }

    @objid ("a1bf9233-f2a7-498d-9473-a551322763e4")
    public Alimento() {
    }

}
